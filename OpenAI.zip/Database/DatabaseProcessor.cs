﻿using Microsoft.Data.SqlClient;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Chatbot.DotNet.Service.Database
{
    public class DatabaseProcessor
    {
        public string ConnectionString { get; private set; }

        public DatabaseProcessor(string connectionString)
        {
            ConnectionString = connectionString;
        }
        public string ExtractMonthFromMessage(string message)
        {
            // Simple list of month names
            string[] months = new string[] {
        "January", "February", "March", "April", "May", "June", "July", "August", "September",
        "October", "November", "December"
    };

            // Search for month names in the user message
            foreach (var month in months)
            {
                if (message.ToLower().Contains(month.ToLower()))
                {
                    return month;  // Return the first matched month
                }
            }

            // Default to the current month if not found
            return DateTime.Now.ToString("MMMM");
        }

        public string ExtractYearFromMessage(string message)
        {
            // Look for a 4-digit number (assumed to be the year)
            var match = Regex.Match(message, @"\b\d{4}\b");
            return match.Success ? match.Value : DateTime.Now.Year.ToString();
        }


        public async Task<string> GetPrompt(string userMessage)
        {
            var prompt = new StringBuilder();
            prompt.AppendLine("You are an AI assistant that generates SQL Server queries based on the user's request.");
            prompt.AppendLine("Use the following SQL views as reference only. Do not modify or explain them.");
            prompt.AppendLine();

            prompt.AppendLine("-- View: vw_Chatbot1");
            prompt.AppendLine(@"CREATE VIEW [dbo].[vw_Chatbot1] AS
SELECT 
    [ProjectDirector],
    [ReferenceNo],
    [LeanEngineer],
    [ActionStatus],
    [InitiatorName],
    [SavedAmount],
    [Project],
    [ManHours],
    [Date_WeekOfReport],
    SUM([SavedAmount]) OVER () AS TotalSavedAmount
");
            if (userMessage.ToLower().Contains("kaizen") || userMessage.ToLower().Contains("project"))
            {
                prompt.AppendLine("-- Kaizen/Project-related query:");

                // Look for "how many" phrase
                if (userMessage.ToLower().Contains("how many"))
                {
                    // Look for specific month or year
                    string month = ExtractMonthFromMessage(userMessage);  // Implement this function to get the month from the message
                    string year = ExtractYearFromMessage(userMessage);    // Implement this function to get the year from the message

                    prompt.AppendLine($@"
SELECT 
    [W_Month] AS [Month],
    COUNT(*) AS KaizenCount
FROM [vw_Chatbot1]
WHERE [W_Month] = '{month}'  -- Dynamically inserted month (e.g., 'April')
  AND [W_Year] = {year}      -- Dynamically inserted year (e.g., 2025)
GROUP BY [W_Month], [W_Year]
ORDER BY [W_Month];
");
                }
                else
                {
                    // General Kaizen/project query
                    prompt.AppendLine("SELECT * FROM [vw_Chatbot1];");
                }
            }

            prompt.AppendLine("-- View: vw_Chatbot2");
            prompt.AppendLine(@"CREATE VIEW [dbo].[vw_Chatbot2] AS
SELECT 
    [FilesTranID],
    [ReferenceNo],
    [UploadVideoBefore],
    [FileName_UploadVideoBefore],
    [FileTypeVideoBefore],
    [UploadVideoAfter],
    [FileName_UploadVideoAfter],
    [FileTypeVideoAfter],
    [UploadCalculations],
    [FileName_UploadCalculations],
    [FileTypeUploadCalculations]
");

            prompt.AppendLine();

            prompt.AppendLine("-- View: vw_Chatbot4");
            prompt.AppendLine("CREATE VIEW [dbo].[vw_Chatbot4] AS SELECT [K].[ReferenceNo], [K].[Supporter_MngRewardedAmount] FROM [Kaizen].[dbo].[tbl_KaizenOwner] [K];");

            prompt.AppendLine();
            prompt.AppendLine("-- View: vw_Chatbot3");
            prompt.AppendLine("CREATE VIEW [dbo].[vw_Chatbot3] AS SELECT [ReferenceNo], [FowardDept] AS [ForwardDept], [ForwardedUserName], [ForwardStatus]");

            prompt.AppendLine();
            prompt.AppendLine("-- User Request:");
            prompt.AppendLine($"\"{userMessage}\"");
            prompt.AppendLine();
            prompt.AppendLine("CREATE VIEW [dbo].[vw_Chatbot5] AS SELECT DISTINCT [Role] FROM [tbl_LoginMaster] WHERE [Role] != ''");
            prompt.AppendLine("-- Generate ONLY the raw SQL Server query. NO explanation, NO comments, NO markdown. Just the SQL.");

            return prompt.ToString();
        }
        public async Task<(byte[] Data, string ContentType)?> GetImageFromDatabaseByReferenceNoAsync(string referenceNo, string imageSource)
        {
            string imageQuery = "";

            if (imageSource.ToLower() == "before")
                imageQuery = $"SELECT UploadVideoBefore FROM [dbo].[vw_Chatbot2] WHERE ReferenceNo = @refNo";
            else if(imageSource.ToLower()=="after")
                imageQuery = $"SELECT UploadVideoAfter FROM [dbo].[vw_Chatbot2] WHERE ReferenceNo = @refNo";

            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    await conn.OpenAsync();
                    using (SqlCommand cmd = new SqlCommand(imageQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@refNo", referenceNo);

                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                var bytes = reader[0] as byte[];
                                return (bytes, "image/jpeg");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the error if needed
                return null;
            }

            return null;
        }

        public async Task<(byte[] Data, string ContentType)?> GetImageFromDatabaseAsync(int imageId, string imageSource)
        {
            // Simulated database access — replace with your actual EF or DB access logic
            // Example:
            // var image = await dbContext.Images.FirstOrDefaultAsync(x => x.Id == imageId);
            // if (image == null) return null;
            // return (image.Data, image.ContentType);
            string imageQuery = "";
            if (imageSource == "before")
                imageQuery = $"select UploadVideoBefore  from [dbo].[vw_Chatbot2] where id={imageId}";
            else if (imageSource == "after")
                imageQuery = $"select UploadVideoAfter  from [dbo].[vw_Chatbot2]  WHERE id={imageId}";


            byte[] image = await QueryDatabaseForBinary(imageQuery);

            // var image = await dbContext.Images.FirstOrDefaultAsync(x => x.Id == imageId);
            if (image == null) return null;
            return (image, "image/jpeg");

            // For demo purposes: read from local file system
            string imagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "building1.jpg");

            if (!File.Exists(imagePath))
            {
                return null;
            }

            byte[] imageBytes = await File.ReadAllBytesAsync(imagePath);
            return (imageBytes, "image/jpeg");
        }


        public async Task<byte[]> QueryDatabaseForBinary(string query)
        {

            // Execute the query
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {

                            if (await reader.ReadAsync())
                            {
                                return (byte[])reader.GetValue(0); // or reader.GetFieldValue<byte[]>(0)
                            }

                            return null; // or throw an exception if no result is unexpected
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
      public async Task<(byte[] Data, string ContentType, string FileName)?> GetExcelFromDatabaseAsync(string referenceNo)
        {
            string query = @"
        SELECT UploadCalculations, 
               FileTypeUploadCalculations, 
               FileName_UploadCalculations
        FROM dbo.vw_Chatbot2
        WHERE ReferenceNo = @ReferenceNo";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@ReferenceNo", referenceNo);
                await connection.OpenAsync();

                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        var fileData = reader["UploadCalculations"] as byte[];
                        var fileType = reader["FileTypeUploadCalculations"]?.ToString() ?? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                        var fileName = reader["FileName_UploadCalculations"]?.ToString() ?? "Kaizen_Calculations.xlsx";

                        if (fileData != null)
                            return (fileData, fileType, fileName);
                    }
                }
            }

            return null;
        }
        

            


        public async Task<(byte[] Data, string ContentType)?> GetVideoFromDatabaseByReferenceNoAsync(string referenceNo, string columnName)
        {
            // e.g., columnName = "UploadVideoBefore"
            string query = $@"
            SELECT {columnName}, FileType{columnName}
            FROM [dbo].[tbl_KaizensSubmission]
            WHERE ReferenceNo = @ReferenceNo";

            using (SqlConnection connection = new SqlConnection(ConnectionString)) // ✅ Fixed this line
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@ReferenceNo", referenceNo);
                await connection.OpenAsync();

                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        var data = reader[columnName] as byte[];
                        var contentType = reader[$"FileType{columnName}"]?.ToString() ?? "video/mp4"; // fallback

                        if (data != null && !string.IsNullOrWhiteSpace(contentType))
                        {
                            return (data, contentType);
                        }
                    }
                }
            }

            return null;
        }
        public async Task<string> QueryDatabase(string query)
        {   

            // Execute the query
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows) return "No records found.";

                            List<Dictionary<string, object>> records = new List<Dictionary<string, object>>();
                            while (await reader.ReadAsync())
                            {
                                Dictionary<string, object> row = new Dictionary<string, object>();

                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    row[reader.GetName(i)] = reader[i] is DBNull ? null : reader[i];
                                }

                                records.Add(row);
                            }

                            return JsonSerializer.Serialize(records, new JsonSerializerOptions { WriteIndented = true });

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error querying database: " + ex.Message;
            }
        }
    }
}

