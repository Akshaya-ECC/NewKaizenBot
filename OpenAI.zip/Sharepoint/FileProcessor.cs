﻿using Azure.Identity;
using iText.Kernel.Pdf.Canvas.Parser;
using iText.Kernel.Pdf;
using Microsoft.Graph;
using Microsoft.Graph.Models;
using System.Text.RegularExpressions;
using System.Security.Cryptography.Pkcs;

namespace Chatbot.DotNet.Service.Sharepoint
{
    public class FileProcessor
    {

        // Replace with your Azure AD credentials
        string tenantId = "ec47277b-54fd-4fd6-968d-d017d3cc871e";
        string clientId = "774d4ceb-8aad-4ea3-b15c-5b50f66d8171";
        string clientSecret = "";
        string[] scopes = { "https://graph.microsoft.com/.default" };

        string siteName = "copilottestchat"; // Your SharePoint site name
        string driveFolderPath = "Audit"; // Path to folder inside SharePoint
                                          

        public async Task<string> GetAllSharepointFiles(string userMessage)
        {
            try
            { 
                var credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
                var graphClient = new GraphServiceClient(credential);

                try
                {
                    var site = await graphClient.Sites[$"eccdubai.sharepoint.com:/sites/{siteName}"].GetAsync();
                    Console.WriteLine($"Site ID: {site.Id}");

                    // ✅ Get the Document Library (Drive)
                    var drive = await graphClient.Sites[site.Id].Drive.GetAsync();

                    // ✅ Get Folder
                    var folder = await graphClient
                        .Drives[drive.Id]
                        .Root
                        .ItemWithPath(driveFolderPath)
                        .GetAsync();

                    string data;
                    return await GetFolderData(userMessage, graphClient, drive, folder ); 
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
 
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;

        }

        public async Task<string> GetAllOnedriveFiles(string userMessage,string userEmail)
        {
            try
            {
                //string userEmail = "mohammed.abdulhameed@eccgroup.ae"; // User's OneDrive email
                var credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
                var graphClient = new GraphServiceClient(credential);
                string folderPath = "Thrash/Download/notes tech"; // Folder path

                try
                {
                    // ✅ Get OneDrive for the user
                    var drive = await graphClient.Users[userEmail].Drive.GetAsync();
                    Console.WriteLine($"Drive ID: {drive.Id}");

                    // ✅ Get the folder in OneDrive
                    var folder = await graphClient
                        .Drives[drive.Id]
                        .Root
                        .ItemWithPath(folderPath)
                        .GetAsync();

                    Console.WriteLine($"Folder ID: {folder.Id}, Name: {folder.Name}");

                    string data="";

                    var files = await graphClient
                    .Drives[drive.Id]
                    .Items[folder.Id]
                    .Children
                    .GetAsync();

                    Console.WriteLine("Files in the folder:");
                    int i = 0;
                    foreach (var file in files.Value)
                    {
                        Console.WriteLine($"- {file.Name} ({file.Id})");
                        //data+= $"-{i++} {file.Name} ({file.Id})";
                        data += $"{file.Name}\r\n";
                    }
                    return data;
                    //return await GetFolderData(userMessage, graphClient, drive, folder );
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;

        }

        private async Task<string> GetFolderData(string userMessage, GraphServiceClient graphClient, Drive? drive, DriveItem? folder )
        {
            string data = "";
            // ✅ Get Folder Contents
            var folderItems = await graphClient
                .Drives[drive.Id]
                .Items[folder.Id]
                .Children
                .GetAsync();

            data = "";
            bool exists = false;
            Console.WriteLine("Files in the folder:");
            foreach (var item in folderItems.Value)
            {

                string requiredString = RemoveSpecialCharacters(userMessage);
                string fileName = RemoveSpecialCharacters(item.Name);
                (exists, data) = await ReadFileContent(item, drive, graphClient, requiredString);
                if (exists)
                {
                    return data;
                }

                Console.WriteLine($"File: {item.Name} - {item.WebUrl}");
            }
            return data;
        }

        public async Task<(bool,string)> ReadFileContent(DriveItem item, Drive drive, GraphServiceClient graphClient, string requiredString)
        {
            string data = "";
            if (item.File == null)
                return (false,"");
            bool exists = false;
            string fileName = RemoveSpecialCharacters(item.Name);
            if (fileName.Contains(requiredString, StringComparison.OrdinalIgnoreCase) )
            {
                var fileContentStream = await graphClient
                    .Drives[drive.Id]
                    .Items[item.Id]
                    .Content
                    .GetAsync();

                exists = true;

                if (item.File.MimeType == "application/pdf")
                {
                    // Read PDF content
                    using (PdfReader pdfReader = new PdfReader(fileContentStream))
                    using (PdfDocument pdfDoc = new PdfDocument(pdfReader))
                    {
                        string pdfText = "";
                        for (int i = 1; i <= pdfDoc.GetNumberOfPages(); i++)
                        {
                            pdfText += PdfTextExtractor.GetTextFromPage(pdfDoc.GetPage(i)) + "\n";
                        }

                        Console.WriteLine($"Content of {item.Name} (PDF): \n{pdfText}");
                        data = pdfText;
                    }
                }
                else
                {
                    // Read text content for non-PDF files
                    using (StreamReader reader = new StreamReader(fileContentStream))
                    {
                        string fileContent = await reader.ReadToEndAsync();
                        Console.WriteLine($"Content of {item.Name}: \n{fileContent}");
                        data = fileContent;
                    }
                }
            }
            return (exists,data);
        }

        string RemoveSpecialCharacters(string input)
        {
            return input;
            //return Regex.Replace(input, @"[^a-zA-Z0-9]", "");
        }

    }
}
