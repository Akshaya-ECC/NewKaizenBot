﻿using System.Text.Json.Serialization;


namespace Chatbot.DotNet.Service.OpenAI
{
    public class Message
    {
        [JsonPropertyName("role")]
        public string Role { get; set; }

        [JsonPropertyName("content")]
        public string Content { get; set; }

        [JsonPropertyName("refusal")]
        public object Refusal { get; set; }
    }


}


