﻿namespace Chatbot.DotNet.Service.OpenAI
{
    public class ChatRequest
    {
        public string Message { get; set; }
        public string role { get; set; }
    }


}


