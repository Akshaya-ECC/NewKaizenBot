﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using System;
using Microsoft.Data.SqlClient;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.Identity.Client;
using System.Text.RegularExpressions;

using Microsoft.Graph;
using Azure.Identity;
using Microsoft.Graph.Models;
using Chatbot.DotNet.Service.Google;
using Chatbot.DotNet.Service.Database;
using Chatbot.DotNet.Service.Sharepoint;
namespace Chatbot.DotNet.Service.OpenAI
{
    public class AIProcessor
    {
        public string OpenAIKey { get; private set; }
        public string ConnectionString { get; private set; }

        public AIProcessor(string openAIKey, string connectionString)
        {
            OpenAIKey = openAIKey;
            this.ConnectionString = connectionString;
        }

    

        public async Task<(string, string, string, string)> GetOpenAIResponse(string userMessage, string role)
        {
      

        string lowerMessage = userMessage.ToLower();

            // 👇 Handle image requests based on "kaz-" or image keywords
            if (lowerMessage.Contains("image") || lowerMessage.Contains("photo") || lowerMessage.Contains("screenshot"))
            {
                string referenceNo = ExtractReferenceNo(userMessage);
                string imageSource = lowerMessage.Contains("before") ? "before" : "after";

                if (!string.IsNullOrEmpty(referenceNo))
                {
                    var dbProcessor = new DatabaseProcessor(ConnectionString);
                    var result = await dbProcessor.GetImageFromDatabaseByReferenceNoAsync(referenceNo, imageSource);

                    if (result != null)
                    {
                        string base64Image = Convert.ToBase64String(result.Value.Data);
                        return ("image", base64Image, "", result.Value.ContentType); // 👈 return image directly
                    }
                    else
                    {
                        return ("error", "Image not found for the given Reference No.", "", "");
                    }
                }
                else
                {
                    return ("error", "Missing or invalid Reference No (expected 'KAZ-xxx').", "", "");
                }
            }

            // 👇 Handle SQL-related requests
            if (lowerMessage.Contains("leanengineer") ||
                lowerMessage.Contains("kaz-") ||
                lowerMessage.Contains("referenceno")||
                lowerMessage.Contains("project") ||
                lowerMessage.Contains("initiatorname") ||
                lowerMessage.Contains("leanactionby") ||
                lowerMessage.Contains("actionstatus") ||
                lowerMessage.Contains("manhours") ||
                lowerMessage.Contains("savedamount") 
                 ||
                lowerMessage.Contains("date_weekofreport") ||
                lowerMessage.Contains("kaizen owner") ||
                lowerMessage.Contains("ownerepromisno") ||
                lowerMessage.Contains("projectdirector") ||
                lowerMessage.Contains("forwarddept") ||
                lowerMessage.Contains("forwarduserempromis") ||
                lowerMessage.Contains("wmonth") ||
                lowerMessage.Contains("kaizen") ||
                lowerMessage.Contains("saved amount") ||
                lowerMessage.Contains("total saved amount") ||
                lowerMessage.Contains("forward username") ||
                lowerMessage.Contains("forwardstatus")|| lowerMessage.Contains("forward dept"))
            {
                DatabaseProcessor dbProcessor = new DatabaseProcessor(ConnectionString);
                string prompt = await dbProcessor.GetPrompt(userMessage);
                string query = await CallOpenAI(prompt);

                // 👇 Role-based security for restricted fields
                if (!role.Contains("Admin")&&!role.Contains("IT") && query.Contains("Supporter_MngRewardedAmount"))
                {
                    throw new Exception("You are not authorized to access this information.");
                }

                return ("query", await dbProcessor.QueryDatabase(query), "", "");
            }

            // 👇 Default OpenAI fallback
            return ("generic", await CallOpenAI(userMessage), "", "");
        }





        private int ExtractImageId(string input)
        {
            // This will match the first number in the input string
            Match match = Regex.Match(input, @"\d+");

            if (match.Success && int.TryParse(match.Value, out int imageId))
            {
                return imageId;
            }

            return -1; // Return -1 if no ID found
        }




        static string ExtractFileId(string input)
        {
            Match match = Regex.Match(input, @"\b([A-Za-z0-9_-]{20,})\b");
            return match.Success ? match.Value : "No valid File ID found";
        }
        public string ExtractReferenceNo(string input)
        {
            Match match = Regex.Match(input, @"KAZ-\d+", RegexOptions.IgnoreCase);
            return match.Success ? match.Value.ToUpper() : null;
        }

        private async Task<string> CallOpenAI(string userMessage)
        {
            using (HttpClient client = new HttpClient())
            {
                var requestBody = new
                {
                    model = "gpt-4.1-nano",
                    messages = new[] { new { role = "user", content = userMessage } }
                };

                string jsonRequest = JsonSerializer.Serialize(requestBody);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {OpenAIKey}");

                HttpResponseMessage response = await client.PostAsync("https://api.openai.com/v1/chat/completions", content);

                if (!response.IsSuccessStatusCode)
                    return "Error fetching AI response.";

                string responseContent = await response.Content.ReadAsStringAsync();
                var responseObject = JsonSerializer.Deserialize<OpenAIResponse>(responseContent);
                // Extract SQL query
                if (responseObject?.Choices != null && responseObject.Choices.Length > 0)
                {
                    return responseObject.Choices[0].Message.Content.Trim();
                }

                return "No SQL query found.";
            }
        }

    }
}

