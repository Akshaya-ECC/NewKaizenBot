﻿namespace Chatbot.DotNet.Service.Google
{
    // Response Model
    public class FileResponse
    {
        public string FileName { get; set; }
        public string MimeType { get; set; }
        public string Base64Content { get; set; }
    }
}
