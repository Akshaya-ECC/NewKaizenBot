﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using System;
using System.Buffers.Text;
using System.IO;
using System.Threading;
using System.Threading.Tasks;


namespace Chatbot.DotNet.Service.Google
{
    public class GoogleDriveService
    {
        private static string[] Scopes = { DriveService.Scope.Drive, DriveService.Scope.DriveFile };
        private static string ApplicationName = "Chatbot.DotNet.Service.Api";

        public async Task<FileResponse> GetFileFromGoogleDrive(string userMessage)
        {
            return await DownloadFile(userMessage);
        }

        public   async Task<FileResponse> DownloadFile(string fileId )
        {
            try
            {
                GoogleCredential googleCredential = await InitService(Scopes);
                var service = new DriveService(new BaseClientService.Initializer
                {
                    HttpClientInitializer = googleCredential,
                    ApplicationName = ApplicationName,
                });

                var request = service.Files.Get(fileId);
                var stream = new MemoryStream();
                await request.DownloadAsync(stream);
                stream.Position = 0;

                var fileMetadata = await service.Files.Get(fileId).ExecuteAsync();
                string fileName = fileMetadata.Name;
                string mimeType = fileMetadata.MimeType;

                string base64 = Convert.ToBase64String(stream.ToArray());
                return new FileResponse
                {
                    FileName = fileName,
                    MimeType = mimeType,
                    Base64Content = base64
                };

            }
            catch(Exception ex)
            {
                return null;
            } 
            
        }

        public async Task<GoogleCredential> InitService(string[] Scopes)
        {
            //AIzaSyBq0T7wVoTtrOSmzHRqMV2JBRZrjZRPjxE 

            try
            {
                GoogleCredential googleCredential;
                using (var stream =   new FileStream("ade-video-creator-5026caac36b8.json", FileMode.Open, FileAccess.Read))
                {
                    googleCredential = await GoogleCredential.FromStreamAsync(stream, CancellationToken.None);
                    googleCredential = googleCredential.CreateScoped(Scopes);
                }
                return googleCredential;
            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            return null;

        }
 

    }
}
